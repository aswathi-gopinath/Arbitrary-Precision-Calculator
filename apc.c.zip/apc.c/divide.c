#include"apc_header.h"
#include<stdio.h>
#include<string.h>

int divide(Dlist **head1, Dlist **tail1,Dlist **head2, Dlist **tail2, Dlist **res_head, Dlist **res_tail, char *argv[])
{
    Dlist *count_head = NULL;
    Dlist *count_tail = NULL;
    insert_first(&count_head, &count_tail, 0);

    Dlist *one_head = NULL;
    Dlist *one_tail = NULL;
    insert_first(&one_head, &one_tail, 1);

    Dlist *temp_res_head = NULL;
    Dlist *temp_res_tail = NULL;
    insert_first(&temp_res_head, &temp_res_tail, 0);

    Dlist *temp_res_head1 = NULL;
    Dlist *temp_res_tail1 = NULL;

    Dlist *prev_count_head = NULL;
    Dlist *prev_count_tail = NULL;

   while (1)
   {
        prev_count_head = count_head;
        prev_count_tail = count_tail;

        Dlist *temp1_head = NULL;
        Dlist *temp1_tail = NULL;
        Dlist *temp2_head = NULL;
        Dlist *temp2_tail = NULL;

        copy_list(temp_res_head, &temp1_head, &temp1_tail);
        copy_list(*head2, &temp2_head, &temp2_tail);

        temp_res_head1 = NULL;
        temp_res_tail1 = NULL;

        add(&temp1_head, &temp1_tail,&temp2_head, &temp2_tail,&temp_res_head1, &temp_res_tail1);
        delete_list(&temp1_head, &temp1_tail);
        delete_list(&temp2_head, &temp2_tail);

        if (compare(&temp_res_head1, head1) == 2)
        {
            *res_head = prev_count_head;
            *res_tail = prev_count_tail;
            return SUCCESS;
        }   
        temp_res_head = temp_res_head1;
        temp_res_tail = temp_res_tail1;

        Dlist *count1_head = NULL;
        Dlist *count1_tail = NULL;
        Dlist *one1_head = NULL;
        Dlist *one1_tail = NULL;

        copy_list(count_head, &count1_head, &count1_tail);
        copy_list(one_head, &one1_head, &one1_tail);

        *res_head = NULL;
        *res_tail = NULL;

        add(&count1_head, &count1_tail,&one1_head, &one1_tail,res_head, res_tail);
        delete_list(&count1_head, &count1_tail);
        delete_list(&one1_head, &one1_tail);

        count_head = *res_head;
        count_tail = *res_tail;
    }
}


int compare(Dlist **res_head, Dlist **head1)
{
    Dlist *temp1 = *res_head;
    Dlist *temp2 = *head1;

    while (temp1 || temp2)
    {
        if (!temp1 && temp2) return 1; //less
        if (temp1 && !temp2) return 2; //greater
        temp1 = temp1->next;
        temp2 = temp2->next;
    }

    temp1 = *res_head;
    temp2 = *head1;

    while (temp1 && temp2)
    {
        if (temp1->data > temp2->data) return 2;
        if (temp1->data < temp2->data) return 1;
        temp1 = temp1->next;
        temp2 = temp2->next;
    }
    return 0;
}

int copy_list(Dlist *res_head, Dlist **temp_res_head, Dlist **temp_res_tail)
{
    while (res_head)
    {
        insert_last(temp_res_head, temp_res_tail, res_head->data);
        res_head = res_head->next;
    }
    return SUCCESS;
}

