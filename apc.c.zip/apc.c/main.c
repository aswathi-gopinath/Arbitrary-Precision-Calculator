#include"apc_header.h"
#include<stdio.h>
#include<string.h>
#include <ctype.h>

int main(int argc, char *argv[])
{
    /*head and tail node of double linked list for operand 1*/
    Dlist *head1 = NULL;
    Dlist *tail1 = NULL;
    /*head and tail node of double linked list for operand 2*/
    Dlist *head2 = NULL;
    Dlist *tail2 = NULL;
      /*head and tail node of double linked list for resultant*/
    Dlist *res_head = NULL;
    Dlist *res_tail = NULL;

    int sign1 = 0, sign3 = 0;/* flags are set when the input operand string is a negative value */
    int sub_flag = 0, div_flag = 0, sign_flag = 0; /*if flags are set, output value will be -ve*/
    char oper; /*store the input operator string*/

    if(validate(argc, argv, &oper) == FAILURE)
    {
        return 0;
    }
    else
    {
        /*change the operator based on the input operands value*/
        switch(oper)
        {
            case '+' :
                if(isdigit(argv[1][0]) && argv[3][0] == '-') // a + (-b)
                {
                    oper = '-';
                    int value = compare_string(argv[1], argv[3]);
                    if(value == 1) sub_flag = 1; // second bigger, swap in sub()
                    if(value == 1) sign_flag = 1; // if second value is bigger , output will be -ve
                    else sign_flag = 0;
                    sign3 = 1; /*set when the second operand is negative*/
                }
                else if(isdigit(argv[3][0]) && argv[1][0] == '-') // (-a) + b
                {
                    oper = '-';
                    int value = compare_string(argv[1], argv[3]);
                    if(value == 1) 
                    {
                        sub_flag = 1; // first number smaller, swap in sub()
                        sign_flag = 0 ;
                        sign1 = 1;
                    }
                    if(value == 2)
                    {
                        sub_flag = 0; //first number greater, no swap
                        sign_flag = 1; //sign -ve 
                        sign1 = 1;
                    }
                }
                else if(argv[1][0] == '-' && argv[3][0] == '-') // (-a) + (-b)
                {
                    oper = '+'; // simple addition
                    sign_flag = 1; // result negative
                    sign1 = 1;
                    sign3 = 1;
                }
                break;

            case '-' :
                if(isdigit(argv[1][0]) && isdigit(argv[3][0])) // a - b
                {
                    int value = compare_string(argv[1], argv[3]);
                    if(value == 1) // a < b
                        sub_flag = 1; // swap in sub()
                    if(value == 1) sign_flag = 1;
                    else sign_flag = 0;
                }
                else if(isdigit(argv[1][0]) && argv[3][0] == '-') // a - (-b)
                {
                    oper = '+';
                    sign3 = 1;
                    sign_flag = 0; // always positive
                }
                else if(argv[1][0] == '-' && isdigit(argv[3][0])) // -a - b
                {
                    oper = '+';
                    sign1 = 1;
                    sign_flag = 1; // always negative
                }
                else if(argv[1][0] == '-' && argv[3][0] == '-') // -a - (-b)
                {
                    oper = '-';
                    sign1 = 1;
                    sign3 = 1;
                    int value = compare_string(argv[1], argv[3]);
                    if(value == 1)
                    {
                         sub_flag = 1; // first smaller, swap in sub()
                         sign_flag = 0;
                    }
                    if(value == 2) 
                    {
                        sub_flag = 0; // second number smaller, no swap in sub()
                        sign_flag = 1;
                    }
                }
                break;

            case '*':
                if(argv[1][0] == '-' && isdigit(argv[3][0]))
                {
                    sign_flag = 1;
                    sign1 = 1;
                }
                else if(argv[3][0] == '-' && isdigit(argv[1][0]))
                {
                    sign_flag = 1;
                    sign3 = 1;
                }
                else if(argv[1][0] == '-' && argv[3][0] == '-')
                {
                    sign_flag = 0;
                    sign1 = 1;
                    sign3 = 1;
                }
                break;

            case '/':
                if(argv[1][0] == '-' && isdigit(argv[3][0]))
                {
                    sign_flag = 1;
                    sign1 = 1;
                }
                else if(argv[3][0] == '-' && isdigit(argv[1][0]))
                {
                    sign_flag = 1;
                    sign3 = 1;
                }
                else if(argv[1][0] == '-' && argv[3][0] == '-')
                {
                    sign_flag = 0;
                    sign1 = 1;
                    sign3 = 1;
                }
                if(compare_string(argv[1], argv[3]) == 1) 
                    div_flag = 1; 
                break;
        }
    }

    if(create_list(&head1, &tail1, &head2, &tail2, argv, sign1, sign3) == SUCCESS)
    {
        /*based on the operator respective arithmetic functions are executed*/
        switch(oper)
        {
            case '+' : 
                if(strcmp(argv[3],"0") == 0) 
                {
                    printf("Result : ");
                    if(sign_flag == 1) printf("-");
                    print_result(head1);
                    break;
                }
                if(strcmp(argv[1],"0") == 0) 
                {
                    if(sign_flag == 1) printf("-");
                    printf("Result : ");
                    print_result(head2);
                    break;
                }
                if(add(&head1, &tail1, &head2, &tail2, &res_head, &res_tail) == SUCCESS)
                {
                    printf("Result : ");
                    if(sign_flag == 1) printf("-");
                    print_result(res_head);
                }
                break;

            case '-' :
                if(strcmp(argv[3],"0") == 0) 
                {
                    printf("Result : ");
                    if(sign_flag == 1) printf("-");
                    print_result(head1);
                    break;
                }
                if(strcmp(argv[1],"0") == 0) 
                {
                    if(sign_flag == 1) printf("-");
                    print_result(head2);
                    break;
                }
                if(sub(&head1, &tail1, &head2, &tail2, &res_head, &res_tail, sub_flag) == SUCCESS)
                {
                    printf("Result : ");
                    if(sign_flag == 1) printf("-");
                    print_result(res_head);
                }
                break;

            case '*':
                printf("Result : ");
                if(strcmp(argv[1], "0") == 0 || strcmp(argv[3], "0") == 0)
                {
                    printf("0\n");
                    break;
                }
                if(mul(&head1, &tail1, &head2, &tail2, &res_head, &res_tail, argv) == SUCCESS)
                {
                    if(sign_flag == 1) printf("-");
                    print_result(res_head);
                }
                break;

            case '/':
                printf("Result : ");
                if(strcmp(argv[3], "0") == 0)
                {
                    printf("Error\n");
                    break;
                }
                if(strcmp(argv[1], "0") == 0)
                {
                    printf("0\n");
                    break;
                }
                if(div_flag == 1)
                {
                    printf("0\n");
                    break;
                }
                if(divide(&head1, &tail1, &head2, &tail2, &res_head, &res_tail, argv) == SUCCESS)
                {
                    if(sign_flag == 1) printf("-");
                    print_result(res_head);
                }
                break;
        }
    }
    return 0;
}


int validate(int argc, char *argv[], char *oper)
{
    /*user should pass 2 operands and an operator*/
    if(argc != 4)
    {
        printf("Invalid no.of arguments passed\n");
        return FAILURE;
    }
    else
    {
        /*operands can be negative bt only contains digits*/
        int i;
        for(i = 0 ; argv[1][i]!='\0';i++)
        {
            if (i == 0 && (argv[1][i] == '-'))
            {
                continue;
            }

            if(!(isdigit(argv[1][i])))
            {
                printf("Operands should be digits only\n");
                return FAILURE;
            }
        }
        for(i = 0 ; argv[3][i]!='\0';i++)
        {
            if (i == 0 && (argv[3][i] == '-'))
            {
                continue;
            }

            if(!(isdigit(argv[3][i])))
            {
                printf("Operands should be digits only\n");
                return FAILURE;
            }
        }
        if(strcmp(argv[2], "+") == 0)
        {
            *oper = '+';
        }
        else if(strcmp(argv[2], "-") == 0)
        {
            *oper = '-';
        }
        else if(strcmp(argv[2], "x") == 0)
        {
            *oper = '*';
        }
        else if(strcmp(argv[2], "/") == 0)
        {
            *oper = '/';
        }
        else
        {
            printf("Invalid operator\n");
            return FAILURE;
        }
        return SUCCESS;
    }
}

int compare_string(char *s1, char*s2)
{
    int i  = 0, j = 0;
    if(s1[0] == '-') i = i+1;
    if(s2[0] == '-') j = j+1;

    int len1 = 0 , len2 = 0;
    while(s1[i]!='\0')
    {
        len1++;
        i++;
    }
    while(s2[j]!='\0')
    {
        len2++;
        j++;
    }

    if(len1 < len2) return 1; //less
    if(len1 > len2) return 2; //greater

    i  = 0, j = 0;
    if(s1[0] == '-') i = i+1;
    if(s2[0] == '-') j = j+1;

    while(s1[i]!='\0' && s2[j]!='\0')
    {
        if(s1[i] < s2[j]) return 1; //less
        else if(s1[i] > s2[j]) return 2; //greater
        else 
        {
            i++;
            j++;
        }
    }
    return 0;
}