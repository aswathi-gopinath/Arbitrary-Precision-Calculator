#include"apc_header.h"
#include<stdio.h>
#include<string.h>

int mul(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **res_head, Dlist **res_tail, char *argv[])
{
    
    Dlist *temp1 = *tail1;
    Dlist *temp2 = *tail2;
    if(strlen(argv[1]) < strlen(argv[3]))
    {
        temp1 = *tail2;
        temp2 = *tail1;
    }
    Dlist *temp1_tail = temp1;

    int carry = 0, pdt;
    while(temp1!=NULL)
    {
        pdt = temp1->data * temp2->data + carry;
        if(pdt > 9)
        {
            carry = pdt/10;
            pdt = pdt % 10;
        }
        else carry = 0;
        if(insert_first(res_head, res_tail, pdt) == FAILURE) return FAILURE;
        temp1 = temp1->prev;
    }
    if(carry > 0) 
        if(insert_first(res_head, res_tail, carry) == FAILURE) return FAILURE;
    Dlist *res_temp_head = NULL;
    Dlist *res_temp_tail = NULL;
    Dlist *res1_head = NULL;
    Dlist *res1_tail = NULL;
    temp2 = temp2->prev;
    int count = 1;
    while(temp2!=NULL)
    {
        carry = 0;
        temp1 = temp1_tail;
        int i;
        for(i = 0; i < count; i++)
        {
            int data = 0;
            if(insert_last(&res_temp_head, &res_temp_tail, data) == FAILURE) return FAILURE;
        }
        while(temp1!=NULL)   
        {
            pdt = temp1->data * temp2->data + carry;
            if(pdt > 9)
            {
                carry = pdt / 10;
                pdt = pdt % 10;
            }
            else carry = 0;
            if(insert_first(&res_temp_head, &res_temp_tail, pdt) == FAILURE) return FAILURE;
            temp1 = temp1->prev;
        }
        if(carry > 0) 
            if(insert_first(&res_temp_head, &res_temp_tail, carry) == FAILURE) return FAILURE;
        count++;
        temp2 = temp2->prev;
        if(add(res_head, res_tail, &res_temp_head, &res_temp_tail, &res1_head, &res1_tail) == FAILURE) return FAILURE;
        if(delete_list(res_head, res_tail) == FAILURE) return FAILURE;
        if(delete_list(&res_temp_head, &res_temp_tail) == FAILURE) return FAILURE;
        *res_head = res1_head;
        *res_tail = res1_tail;
        res1_head = NULL;
        res1_tail = NULL;
    }
    return SUCCESS;
}