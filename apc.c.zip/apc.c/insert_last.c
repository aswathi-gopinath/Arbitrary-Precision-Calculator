#include "apc_header.h"
#include<stdio.h>

int insert_last(Dlist **head, Dlist **tail, int data)
{
    Dlist *new = malloc(sizeof(Dlist));
    if(new == NULL) return FAILURE;
    new->data = data;
    new->next = NULL;
    new->prev = *tail;
    if(*head == NULL) 
    {
        *head = new;
        *tail = new;
        return SUCCESS;
    }
    (*tail)->next = new;
    *tail = new;
    return SUCCESS;
}