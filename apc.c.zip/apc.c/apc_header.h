#ifndef APC_HEADER_H
#define APC_HEADER_H

#include<stdio.h>
#include<stdlib.h>

#define SUCCESS 0
#define FAILURE -1

/*Nodes in the double linked list are created using the structure Dlist
/*Node contains data , next and prev pointers
*/
typedef struct node
{
    int data;
    struct node*prev;
    struct node*next;
}Dlist;

//validate the inputs
int validate(int argc, char *argv[], char *oper);
/*insert data to the first of linked list*/
int insert_first(Dlist **head, Dlist **tail, int data);
/*insert data to the last of linked list*/
int insert_last(Dlist **head, Dlist **tail, int data);
/* function to create list for 2 operands and for the result*/
int create_list(Dlist **head1, Dlist**tail1, Dlist**head2, Dlist**tail2, char*argv[], int sign1, int sign3);
/*add function*/
int  add(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **res_head, Dlist **res_tail);
/*subtraction function*/
int  sub(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **res_head, Dlist **res_tail, int sub_flag);
/*multiplication function*/
int  mul(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **res_head, Dlist **res_tail, char *argv[]);
/*division*/
int  divide(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **res_head, Dlist **res_tail, char *argv[]);
/*to print the resultant linked list as the output*/
void print_result(Dlist *res_head);
/*function to delete the linked list*/
int delete_list(Dlist **head, Dlist **tail);
/*function to compare two linked list*/
int compare(Dlist **res_head, Dlist **head2);
/*function to copy one list to another list*/
int copy_list(Dlist *res_head, Dlist **temp_res_head, Dlist **temp_res_tail);
/*function to compare two input strings*/
int compare_string(char *s1, char*s2);

#endif