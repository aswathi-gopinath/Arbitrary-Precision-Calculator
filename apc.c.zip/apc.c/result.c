#include"apc_header.h"
#include<stdio.h>

void print_result(Dlist *res_head)
{
	while(res_head->data == 0 && res_head->next!=NULL)
		res_head = res_head->next;
	while (res_head!=NULL)		
	{
		/* Printing the result */
			printf("%d",res_head -> data);
		/*Travering in forward direction */
			res_head = res_head->next;
    }
    printf("\n");
}