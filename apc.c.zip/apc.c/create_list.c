#include"apc_header.h"
#include<stdio.h>

int create_list(Dlist **head1, Dlist**tail1, Dlist**head2, Dlist**tail2, char*argv[] ,int sign1, int sign3)
{
    int data,i;
    int j = 0;
    if(sign1 == 1) j = j+1;
    for(i = j; argv[1][i]!='\0'; i++)
    {
        data = argv[1][i] - '0';
        if(insert_last(head1, tail1, data) == FAILURE)
        {
            printf("List cant be created\n");
            return FAILURE;
        }
    }

    int k = 0;
    if(sign3 == 1) k = k+1;
    for(i = k; argv[3][i]!='\0'; i++)
    {
        data = argv[3][i] - '0';
        if(insert_last(head2, tail2, data) == FAILURE)
        {
            printf("List cant be created\n");
            return FAILURE;
        }
    }
    return SUCCESS;
}