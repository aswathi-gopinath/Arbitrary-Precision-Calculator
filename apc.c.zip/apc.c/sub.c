#include"apc_header.h"
#include<stdio.h>
#include<string.h>

int  sub(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **res_head, Dlist **res_tail, int sub_flag)
{
    int  diff;
    int borrow = 0;
    
    Dlist *temp1 = *tail1;
    Dlist *temp2 = *tail2;

    if(sub_flag == 1)
    {
        temp1 = *tail2;
        temp2 = *tail1;
    }

    int value;
    while(temp1!=NULL)
    {
        if(temp2 == NULL) value = 0;
        else value = temp2->data;
        if((temp1->data - borrow) < value)
        {
            temp1->data = temp1->data + 10 - borrow;
            borrow = 1;
        }
        else
        {
            temp1->data = temp1->data - borrow;
            borrow = 0;
        }
        diff = temp1->data - value;
        insert_first(res_head, res_tail, diff);
        temp1 = temp1->prev;
        if(temp2!=NULL)
            temp2 = temp2->prev;
    }
    return SUCCESS;
}