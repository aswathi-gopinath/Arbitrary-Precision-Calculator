#include"apc_header.h"
#include<stdio.h>

int add(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **res_head, Dlist **res_tail)
{
    int sum, carry = 0;
    while(*tail1!=NULL || *tail2!= NULL)
    {
        if(*tail1 == NULL)
        {
            sum = (*tail2)->data + carry;
            *tail2 = (*tail2)->prev;
        }
        else if(*tail2 == NULL)
        {
            sum = (*tail1)->data + carry;
            *tail1 = (*tail1)->prev;
        }
        else
        {
            sum = (*tail1)->data + (*tail2)->data + carry;
             *tail1= (*tail1)->prev;
             *tail2 = (*tail2)->prev;
        }
        if(sum > 9) carry = 1;
        else carry = 0;
        sum = sum % 10;
        insert_first(res_head, res_tail, sum);
    }
    if(carry == 1) insert_first(res_head, res_tail, carry);
    return SUCCESS;
}